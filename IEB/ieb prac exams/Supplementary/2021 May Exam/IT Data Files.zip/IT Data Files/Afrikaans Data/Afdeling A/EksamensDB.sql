#
# DUMP FILE
#
# Database is ported from MS Access
#------------------------------------------------------------------
# Created using "MS Access to MySQL" form http://www.bullzip.com
# Program Version 5.1.242
#
# OPTIONS:
#   sourceusername=
#   sourcepassword=
#   sourcesystemdatabase=
#   destinationdatabase=WeddingDB
#   storageengine=MyISAM
#   dropdatabase=1
#   createtables=1
#   unicode=1
#   autocommit=1
#   transferdefaultvalues=1
#   transferindexes=1
#   transferautonumbers=1
#   transferrecords=1
#   columnlist=1
#   tableprefix=
#   negativeboolean=0
#   ignorelargeblobs=0
#   memotype=LONGTEXT
#

DROP DATABASE IF EXISTS `EksamensDB`;
CREATE DATABASE IF NOT EXISTS `EksamensDB`;
USE `EksamensDB`;

#
# Tabelstruktuur vir tabel 'tblKandidate'
#

DROP TABLE IF EXISTS `tblKandidate`;

CREATE TABLE `tblKandidate` (
  `StudentID` INTEGER, 
  `VraestelID` VARCHAR(10), 
  INDEX (`VraestelID`), 
  INDEX (`StudentID`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Stort data vir tabel 'tblKandidate'
#

INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (1, 'LIF2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (2, 'ZUL1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (2, 'TOU');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (2, 'ENGH1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (2, 'ZUL2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (2, 'ITN1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (3, 'CON');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (3, 'HIS2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (4, 'AFRH2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (4, 'MAT1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (4, 'ECO1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (5, 'MATL2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (5, 'CAT2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (6, 'VIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (6, 'GEO2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (6, 'CON');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (6, 'GEO1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (7, 'MATL2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (7, 'ECO1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (7, 'TOU');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (8, 'LIF2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (8, 'CAT2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (9, 'GEO2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (9, 'EGD1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (10, 'HIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (11, 'GEO2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (11, 'EGD1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (12, 'ENGH1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (13, 'AFRA1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (13, 'DRA');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (13, 'PHY2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (13, 'TOU');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (14, 'BUS2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (14, 'ENGA2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (14, 'AFRH2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (15, 'ZUL2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (15, 'LIF1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (15, 'PHY2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (16, 'MATL2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (16, 'HIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (16, 'EGD2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (16, 'LIF1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (17, 'HIS2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (17, 'CAT1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (18, 'MAT2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (18, 'EGD1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (19, 'ACC1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (19, 'CAT2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (20, 'ZUL2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (20, 'AFRH1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (21, 'MATL1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (22, 'TOU');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (23, 'ZUL2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (24, 'AFRH1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (25, 'HIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (25, 'ENGA2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (26, 'PHY1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (26, 'TOU');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (27, 'ZUL1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (28, 'TOU');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (28, 'ECO1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (28, 'ACC1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (29, 'MATL1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (29, 'PHY1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (29, 'LIF1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (29, 'LIF2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (30, 'EGD1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (30, 'MATL2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (31, 'AFRA1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (31, 'MAT1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (31, 'EGD1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (31, 'PHY2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (31, 'AFRH2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (31, 'BUS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (31, 'CAT1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (32, 'ACC1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (32, 'ENGH2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (32, 'LIF1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (33, 'GEO1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (33, 'MAT1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (33, 'ENGH2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (34, 'LIF1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (34, 'LIF2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (34, 'MATL2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (35, 'EGD1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (35, 'MAT1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (35, 'LIF2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (36, 'ECO1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (36, 'PHY1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (37, 'BUS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (38, 'BUS2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (38, 'GEO2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (38, 'GEO1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (38, 'HIS2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (38, 'AFRH1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (38, 'MATL2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (38, 'PHY2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (38, 'ECO1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (39, 'CAT1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (40, 'BUS2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (41, 'LIF1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (41, 'CAT1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (41, 'HIS2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (42, 'VIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (42, 'AFRA1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (43, 'DRA');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (44, 'ENGA2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (45, 'EGD1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (46, 'CON');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (47, 'HIS2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (47, 'GEO1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (47, 'VIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (48, 'ITN2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (48, 'ENGA2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (49, 'BUS2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (49, 'ZUL2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (49, 'DRA');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (50, 'LIF1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (51, 'GEO2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (52, 'CAT1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (53, 'AFRA1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (53, 'ACC2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (53, 'ENGH1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (54, 'MAT1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (54, 'BUS2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (54, 'ACC1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (55, 'MAT1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (55, 'MAT2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (55, 'VIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (56, 'BUS2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (56, 'BUS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (56, 'PHY2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (57, 'PHY2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (57, 'ACC2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (58, 'ZUL2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (58, 'ENGH1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (59, 'VIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (59, 'TOU');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (59, 'EGD1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (60, 'VIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (61, 'ITN2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (61, 'BUS2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (62, 'HIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (63, 'CAT1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (63, 'CAT2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (64, 'CAT2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (64, 'ECO1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (64, 'PHY2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (64, 'ITN2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (65, 'HIS2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (65, 'GEO1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (65, 'LIF1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (66, 'ENGH2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (66, 'CON');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (66, 'ECO1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (66, 'PHY2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (67, 'AFRA2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (67, 'VIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (68, 'ACC2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (68, 'MATL2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (68, 'MAT2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (69, 'AFRA1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (70, 'MATL1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (71, 'CON');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (71, 'EGD1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (71, 'HIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (72, 'LIF2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (72, 'AFRA1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (72, 'AFRA2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (73, 'MAT2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (73, 'MAT1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (73, 'ENGA2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (74, 'ENGH1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (74, 'EGD1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (75, 'ENGH2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (76, 'ZUL2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (77, 'VIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (77, 'MATL1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (78, 'AFRA1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (78, 'HIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (79, 'ENGH1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (80, 'MAT2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (80, 'ACC1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (81, 'PHY2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (81, 'ENGH2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (82, 'LIF1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (83, 'ENGH2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (83, 'AFRA2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (84, 'GEO1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (85, 'EGD1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (85, 'ACC2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (85, 'ENGH2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (86, 'MATL2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (87, 'EGD2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (88, 'ENGA2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (89, 'PHY1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (90, 'HIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (90, 'CON');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (90, 'ITN1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (91, 'CAT2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (91, 'ENGH2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (91, 'VIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (91, 'AFRH2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (92, 'ENGH2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (92, 'HIS2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (93, 'PHY1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (93, 'ACC2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (94, 'PHY2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (94, 'VIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (95, 'BUS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (95, 'MAT1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (96, 'ENGA2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (97, 'AFRA1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (98, 'LIF2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (98, 'ACC2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (98, 'ENGH1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (98, 'CON');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (99, 'LIF1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (99, 'AFRA2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (99, 'ITN2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (99, 'HIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (99, 'AFRH2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (100, 'MATL1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (100, 'LIF1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (101, 'GEO1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (101, 'ENGH1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (102, 'AFRH1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (103, 'MATL2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (103, 'PHY2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (103, 'AFRH1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (104, 'HIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (105, 'LIF1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (105, 'ZUL2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (106, 'AFRH1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (106, 'ZUL2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (107, 'PHY1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (107, 'TOU');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (108, 'ZUL1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (109, 'EGD1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (109, 'MAT1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (110, 'LIF2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (110, 'BUS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (111, 'BUS2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (111, 'CON');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (112, 'PHY2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (113, 'ACC2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (113, 'VIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (114, 'ITN2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (114, 'BUS2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (114, 'CON');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (115, 'EGD1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (115, 'HIS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (115, 'ENGH1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (116, 'EGD1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (116, 'ZUL2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (116, 'LIF1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (116, 'AFRH1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (117, 'CAT2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (117, 'MAT2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (117, 'MAT1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (117, 'BUS1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (117, 'MATL1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (118, 'MAT1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (118, 'ECO1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (119, 'DRA');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (119, 'CON');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (119, 'AFRA2');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (119, 'AFRA1');
INSERT INTO `tblKandidate` (`StudentID`, `VraestelID`) VALUES (120, 'ECO1');
# 269 records

#
# Tabelstruktuur vir tabel 'tblStudente'
#

DROP TABLE IF EXISTS `tblStudente`;

CREATE TABLE `tblStudente` (
  `StudentID` INTEGER NOT NULL AUTO_INCREMENT, 
  `Voornaam` VARCHAR(50), 
  `Van` VARCHAR(50), 
  `Geboortedatum` DATE, 
  `Geslag` VARCHAR(1), 
  `Sentrum` INTEGER, 
  PRIMARY KEY (`StudentID`), 
  INDEX (`StudentID`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Stort data vir tabel 'tblStudente'
#

INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (1, 'Keiko', 'Abbott', '1999-03-30', 'V', 1003);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (2, 'Eagan', 'Alvarado', '2000-04-06', 'M', 1006);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (3, 'Cynthia', 'Andrews', '1999-05-08', 'V', 1000);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (4, 'Kelsie', 'Atkinson', '2000-04-09', 'V', 1007);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (5, 'Nichole', 'Avila', '2000-03-29', 'V', 1014);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (6, 'Colette', 'Baldwin', '2000-05-24', 'V', 1012);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (7, 'Tate', 'Bates', '2000-01-21', 'M', 1007);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (8, 'Fulton', 'Bauer', '1999-02-25', 'M', 1016);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (9, 'Hector', 'Beasley', '1999-12-30', 'M', 1019);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (10, 'Lynn', 'Becker', '2000-05-29', 'V', 1011);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (11, 'Ira', 'Bell', '1999-03-07', 'M', 1004);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (12, 'Alden', 'Bell', '2000-04-01', 'M', 1008);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (13, 'Alfreda', 'Bell', '2000-04-27', 'V', 1019);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (14, 'Vincent', 'Berg', '1999-11-30', 'M', 1012);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (15, 'Rigel', 'Blackburn', '1999-03-20', 'M', 1004);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (16, 'Deborah', 'Blackburn', '2000-05-19', 'V', 1005);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (17, 'Wanda', 'Blair', '2000-06-05', 'V', 1005);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (18, 'Oren', 'Blanchard', '1999-09-13', 'M', 1009);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (19, 'Keelie', 'Boyd', '1999-10-10', 'V', 1016);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (20, 'Beatrice', 'Bradshaw', '1999-10-18', 'V', 1019);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (21, 'Ivan', 'Brady', '2000-06-02', 'M', 1008);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (22, 'Hamish', 'Brewer', '1999-01-25', 'M', 1018);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (23, 'Paki', 'Bridges', '2000-04-12', 'M', 1012);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (24, 'May', 'Brock', '1999-12-05', 'V', 1017);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (25, 'Castor', 'Brown', '2000-02-14', 'M', 1015);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (26, 'Forrest', 'Bryan', '1999-03-27', 'M', 1016);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (27, 'Chancellor', 'Buck', '1999-03-29', 'M', 1017);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (28, 'Forrest', 'Burch', '1999-05-26', 'M', 1020);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (29, 'Cedric', 'Burgess', '2000-05-14', 'M', 1017);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (30, 'Jemima', 'Burton', '1999-10-31', 'V', 1013);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (31, 'Deborah', 'Cain', '1999-04-17', 'V', 1006);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (32, 'Erich', 'Carey', '2000-03-16', 'M', 1005);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (33, 'Jameson', 'Carrillo', '1999-05-13', 'M', 1009);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (34, 'Christopher', 'Carter', '2000-01-20', 'M', 1020);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (35, 'Nina', 'Chan', '2000-06-12', 'V', 1008);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (36, 'Barbara', 'Chan', '1999-01-10', 'V', 1018);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (37, 'Bethany', 'Chase', '1999-11-29', 'V', 1010);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (38, 'Uriel', 'Chavez', '1999-04-21', 'M', 1009);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (39, 'Carter', 'Christian', '1999-04-16', 'M', 1014);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (40, 'Eagan', 'Clark', '1999-02-10', 'M', 1011);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (41, 'Jael', 'Clay', '2000-05-22', 'V', 1003);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (42, 'Thor', 'Cleveland', '1999-04-30', 'M', 1018);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (43, 'Solomon', 'Cline', '2000-06-03', 'M', 1014);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (44, 'Kessie', 'Cline', '1999-04-15', 'V', 1014);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (45, 'Ezekiel', 'Collier', '1999-11-22', 'M', 1002);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (46, 'Harding', 'Colon', '2000-01-24', 'M', 1020);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (47, 'Demetria', 'Combs', '1999-01-27', 'V', 1006);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (48, 'Sarah', 'Cooke', '1999-10-30', 'V', 1014);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (49, 'Hayden', 'Daniel', '1999-09-13', 'M', 1003);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (50, 'Callum', 'Daugherty', '1999-01-14', 'M', 1007);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (51, 'Odette', 'Day', '1999-07-16', 'V', 1005);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (52, 'Hanna', 'Delacruz', '1999-01-18', 'V', 1009);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (53, 'Karyn', 'Delacruz', '2000-05-07', 'V', 1009);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (54, 'Whoopi', 'Diaz', '1999-11-07', 'V', 1017);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (55, 'Olympia', 'Dillon', '1999-11-28', 'V', 1007);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (56, 'Kathleen', 'Donovan', '1999-11-30', 'V', 1016);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (57, 'Walter', 'Duncan', '2000-04-14', 'M', 1014);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (58, 'Rahim', 'Edwards', '1999-12-24', 'M', 1020);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (59, 'Ahmed', 'Elliott', '1999-07-12', 'M', 1015);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (60, 'Quail', 'Erickson', '1999-10-24', 'V', 1017);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (61, 'Julie', 'Espinoza', '1999-12-31', 'V', 1006);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (62, 'Andrew', 'Faulkner', '2000-06-08', 'M', 1004);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (63, 'Sybill', 'Ferrell', '1999-10-24', 'V', 1008);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (64, 'Britanni', 'Fields', '1999-10-07', 'V', 1013);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (65, 'Fuller', 'Fisher', '1999-05-18', 'M', 1001);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (66, 'Astra', 'Fitzgerald', '1999-12-29', 'V', 1006);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (67, 'Chadwick', 'Fletcher', '1999-01-05', 'M', 1000);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (68, 'Laurel', 'Flynn', '1999-07-10', 'V', 1007);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (69, 'Clio', 'Forbes', '1999-12-31', 'V', 1003);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (70, 'Justine', 'Fox', '1999-05-20', 'V', 1017);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (71, 'Ian', 'Gaines', '1999-10-02', 'M', 1009);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (72, 'Garrison', 'Gallegos', '1999-12-27', 'M', 1009);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (73, 'Hasad', 'Garcia', '2000-01-25', 'M', 1005);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (74, 'Cameron', 'Garcia', '2000-06-04', 'M', 1006);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (75, 'Desirae', 'Gentry', '2000-02-11', 'V', 1014);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (76, 'Rae', 'Giles', '1999-03-13', 'V', 1017);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (77, 'Jackson', 'Gillespie', '1999-07-01', 'M', 1020);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (78, 'Melyssa', 'Gillespie', '2000-03-07', 'V', 1007);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (79, 'Emerald', 'Gilmore', '1999-03-30', 'V', 1000);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (80, 'Priscilla', 'Glover', '2000-03-19', 'V', 1015);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (81, 'Lila', 'Grant', '1999-09-13', 'V', 1001);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (82, 'Pandora', 'Green', '1999-02-16', 'V', 1001);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (83, 'Grace', 'Guthrie', '2000-01-26', 'V', 1012);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (84, 'Aladdin', 'Haley', '1999-01-02', 'M', 1020);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (85, 'Maggy', 'Harding', '1999-09-05', 'V', 1008);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (86, 'Adria', 'Hartman', '1999-06-06', 'V', 1006);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (87, 'Brenda', 'Haynes', '1999-03-12', 'V', 1009);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (88, 'Gannon', 'Hays', '1999-03-13', 'M', 1011);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (89, 'Deacon', 'Hays', '1999-10-31', 'M', 1000);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (90, 'Eugenia', 'Henderson', '1999-06-14', 'V', 1000);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (91, 'Kelly', 'Henson', '1999-12-11', 'M', 1015);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (92, 'Oleg', 'Herman', '1999-05-29', 'M', 1007);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (93, 'Kennedy', 'Hernandez', '2000-06-11', 'M', 1008);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (94, 'Alice', 'Herring', '2000-03-30', 'V', 1020);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (95, 'Maxwell', 'Hester', '1999-09-23', 'M', 1015);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (96, 'Alisa', 'Higgins', '1999-07-23', 'V', 1011);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (97, 'Berk', 'Hines', '1999-05-12', 'M', 1010);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (98, 'Jasper', 'Hinton', '1999-08-26', 'M', 1007);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (99, 'Imogene', 'Holden', '1999-04-13', 'V', 1008);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (100, 'Cora', 'Holmes', '1999-03-17', 'V', 1006);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (101, 'Shea', 'Hunt', '1999-11-09', 'V', 1005);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (102, 'Brady', 'Hurst', '1999-12-07', 'M', 1005);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (103, 'Fay', 'Hurst', '1999-07-30', 'V', 1012);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (104, 'Chase', 'Hutchinson', '1999-03-07', 'M', 1016);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (105, 'Lee', 'Jefferson', '2000-04-22', 'V', 1020);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (106, 'Alyssa', 'Joyner', '2000-05-10', 'V', 1005);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (107, 'Hakeem', 'Juarez', '1999-08-22', 'M', 1004);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (108, 'Abbot', 'Kemp', '2000-05-18', 'M', 1017);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (109, 'Eaton', 'King', '2000-06-15', 'M', 1011);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (110, 'Denise', 'Kinney', '2000-05-11', 'V', 1006);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (111, 'Cullen', 'Knapp', '2000-05-20', 'M', 1008);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (112, 'Gisela', 'Langley', '1999-08-11', 'V', 1015);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (113, 'Lois', 'Leon', '1999-08-26', 'V', 1006);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (114, 'Ivor', 'Levy', '2000-03-16', 'M', 1020);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (115, 'Jesse', 'Lloyd', '1999-09-14', 'M', 1016);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (116, 'Slade', 'Logan', '2000-05-18', 'M', 1020);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (117, 'Dylan', 'Lucas', '2000-05-29', 'M', 1020);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (118, 'Roanna', 'Madden', '2000-02-08', 'V', 1012);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (119, 'Alyssa', 'Mann', '1999-06-01', 'V', 1000);
INSERT INTO `tblStudente` (`StudentID`, `Voornaam`, `Van`, `Geboortedatum`, `Geslag`, `Sentrum`) VALUES (120, 'Lila', 'Manning', '1999-12-15', 'V', 1019);
# 120 records

#
# Tabelstruktuur vir tabel 'tblRooster'
#

DROP TABLE IF EXISTS `tblRooster`;

CREATE TABLE `tblRooster` (
  `VraestelID` VARCHAR(10) NOT NULL, 
  `EksamenDatum` DATE, 
  `Vraestel` VARCHAR(60), 
  `BeginTyd` TIME, 
  `EindTyd` TIME, 
  PRIMARY KEY (`VraestelID`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Stort data vir tabel 'tblRooster'
#

INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('ACC1', '2017-03-27', 'Rekeningkunde VI', '09:00:00', '11:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('ACC2', '2017-03-17', 'Rekeningkunde VII', '14:00:00', '16:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('AFRA1', '2017-03-02', 'Afrikaans Eerste Add Taal VI (Lees)', '14:00:00', '16:30:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('AFRA2', '2017-03-09', 'Afrikaans Eerste Add Taal VII (Skryf)', '14:00:00', '16:30:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('AFRH1', '2017-03-01', 'Afrikaans Huistaal VI (Lees)', '14:00:00', '17:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('AFRH2', '2017-03-08', 'Afrikaans Huistaal VII (Skryf)', '14:00:00', '17:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('BUS1', '2017-03-17', 'Besigheidstudies VI', '09:00:00', '11:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('BUS2', '2017-03-15', 'Besigheidstudies VII', '14:00:00', '16:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('CAT1', '2017-03-21', 'Rekenaartoepassingstegnologie VI (Teorie)', '09:00:00', '12:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('CAT2', '2017-03-28', 'Rekenaartoepassingstegnologie VII (Prakties)', '09:00:00', '12:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('CON', '2017-03-10', 'Verbruikerstudies', '09:00:00', '12:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('DRA', '2017-03-22', 'Dramatiese Kunste', '09:00:00', '12:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('ECO1', '2017-03-01', 'Ekonomie', '09:00:00', '12:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('EGD1', '2017-03-23', 'Ingenieursgrafika en -ontwerp VI', '09:00:00', '12:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('EGD2', '2017-03-29', 'Ingenieursgrafika en -ontwerp VII', '09:00:00', '12:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('ENGA1', '2017-03-07', 'Engels Eerste Add Taal VI (Lees)', '14:00:00', '16:30:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('ENGA2', '2017-03-14', 'Engels Eerste Add Taal VII (Skryf)', '14:00:00', '16:30:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('ENGH1', '2017-03-06', 'Engels Huistaal VI (Lees)', '14:00:00', '17:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('ENGH2', '2017-03-13', 'Engels Huistaal VII (Skryf)', '14:00:00', '17:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('GEO1', '2017-03-24', 'Aardrykskunde VI', '09:00:00', '12:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('GEO2', '2017-03-16', 'Aardrykskunde VII', '14:00:00', '15:30:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('HIS1', '2017-03-20', 'Geskiedenis VI', '14:00:00', '17:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('HIS2', '2017-03-06', 'Geskiedenis VII', '09:00:00', '11:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('ITN1', '2017-03-20', 'Inligtingstegnologie VI (Teorie)', '09:00:00', '12:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('ITN2', '2017-03-30', 'Inligtingstegnologie VII (Prakties)', '09:00:00', '12:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('LIF1', '2017-03-15', 'Lewenswetenskappe VI', '09:00:00', '12:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('LIF2', '2017-03-31', 'Lewenswetenskappe VII', '09:00:00', '11:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('MAT1', '2017-03-07', 'Wiskunde VI', '09:00:00', '12:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('MAT2', '2017-03-13', 'Wiskunde VII', '09:00:00', '12:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('MATL1', '2017-03-08', 'Wiskundige Geletterdheid VI', '09:00:00', '12:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('MATL2', '2017-03-14', 'Wiskundige Geletterdheid VII', '09:00:00', '12:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('PHY1', '2017-03-02', 'Fisiese Wetenskappe VI (Fisika)', '09:00:00', '12:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('PHY2', '2017-03-03', 'Fisiese Wetenskappe VII (Chemie)', '09:00:00', '12:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('TOU', '2017-03-16', 'Toerisme', '09:00:00', '12:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('VIS1', '2017-03-09', 'Visuele Kunste VI', '09:00:00', '12:00:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('ZUL1', '2017-03-03', 'IsiZulu Eerste Add Taal VI (Lees)', '14:00:00', '16:30:00');
INSERT INTO `tblRooster` (`VraestelID`, `EksamenDatum`, `Vraestel`, `BeginTyd`, `EindTyd`) VALUES ('ZUL2', '2017-03-10', 'IsiZulu Eerste Add Taal VII (Skryf)', '14:00:00', '16:30:00');
# 37 records
