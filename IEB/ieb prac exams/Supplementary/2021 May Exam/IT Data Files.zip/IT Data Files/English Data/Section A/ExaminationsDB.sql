#
# DUMP FILE
#
# Database is ported from MS Access
#------------------------------------------------------------------
# Created using "MS Access to MySQL" form http://www.bullzip.com
# Program Version 5.1.242
#
# OPTIONS:
#   sourceusername=
#   sourcepassword=
#   sourcesystemdatabase=
#   destinationdatabase=WeddingDB
#   storageengine=MyISAM
#   dropdatabase=1
#   createtables=1
#   unicode=1
#   autocommit=1
#   transferdefaultvalues=1
#   transferindexes=1
#   transferautonumbers=1
#   transferrecords=1
#   columnlist=1
#   tableprefix=
#   negativeboolean=0
#   ignorelargeblobs=0
#   memotype=LONGTEXT
#

DROP DATABASE IF EXISTS `ExaminationsDB`;
CREATE DATABASE IF NOT EXISTS `ExaminationsDB`;
USE `ExaminationsDB`;

#
# Table structure for table 'tblCandidates'
#

DROP TABLE IF EXISTS `tblCandidates`;

CREATE TABLE `tblCandidates` (
  `StudentID` INTEGER, 
  `PaperID` VARCHAR(10), 
  INDEX (`PaperID`), 
  INDEX (`StudentID`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'tblCandidates'
#

INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (1, 'LIF2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (2, 'ZUL1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (2, 'TOU');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (2, 'ENGH1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (2, 'ZUL2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (2, 'ITN1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (3, 'CON');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (3, 'HIS2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (4, 'AFRH2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (4, 'MAT1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (4, 'ECO1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (5, 'MATL2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (5, 'CAT2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (6, 'VIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (6, 'GEO2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (6, 'CON');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (6, 'GEO1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (7, 'MATL2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (7, 'ECO1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (7, 'TOU');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (8, 'LIF2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (8, 'CAT2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (9, 'GEO2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (9, 'EGD1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (10, 'HIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (11, 'GEO2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (11, 'EGD1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (12, 'ENGH1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (13, 'AFRA1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (13, 'DRA');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (13, 'PHY2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (13, 'TOU');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (14, 'BUS2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (14, 'ENGA2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (14, 'AFRH2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (15, 'ZUL2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (15, 'LIF1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (15, 'PHY2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (16, 'MATL2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (16, 'HIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (16, 'EGD2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (16, 'LIF1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (17, 'HIS2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (17, 'CAT1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (18, 'MAT2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (18, 'EGD1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (19, 'ACC1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (19, 'CAT2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (20, 'ZUL2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (20, 'AFRH1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (21, 'MATL1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (22, 'TOU');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (23, 'ZUL2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (24, 'AFRH1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (25, 'HIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (25, 'ENGA2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (26, 'PHY1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (26, 'TOU');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (27, 'ZUL1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (28, 'TOU');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (28, 'ECO1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (28, 'ACC1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (29, 'MATL1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (29, 'PHY1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (29, 'LIF1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (29, 'LIF2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (30, 'EGD1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (30, 'MATL2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (31, 'AFRA1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (31, 'MAT1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (31, 'EGD1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (31, 'PHY2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (31, 'AFRH2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (31, 'BUS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (31, 'CAT1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (32, 'ACC1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (32, 'ENGH2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (32, 'LIF1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (33, 'GEO1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (33, 'MAT1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (33, 'ENGH2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (34, 'LIF1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (34, 'LIF2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (34, 'MATL2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (35, 'EGD1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (35, 'MAT1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (35, 'LIF2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (36, 'ECO1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (36, 'PHY1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (37, 'BUS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (38, 'BUS2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (38, 'GEO2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (38, 'GEO1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (38, 'HIS2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (38, 'AFRH1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (38, 'MATL2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (38, 'PHY2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (38, 'ECO1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (39, 'CAT1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (40, 'BUS2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (41, 'LIF1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (41, 'CAT1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (41, 'HIS2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (42, 'VIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (42, 'AFRA1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (43, 'DRA');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (44, 'ENGA2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (45, 'EGD1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (46, 'CON');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (47, 'HIS2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (47, 'GEO1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (47, 'VIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (48, 'ITN2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (48, 'ENGA2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (49, 'BUS2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (49, 'ZUL2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (49, 'DRA');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (50, 'LIF1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (51, 'GEO2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (52, 'CAT1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (53, 'AFRA1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (53, 'ACC2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (53, 'ENGH1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (54, 'MAT1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (54, 'BUS2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (54, 'ACC1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (55, 'MAT1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (55, 'MAT2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (55, 'VIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (56, 'BUS2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (56, 'BUS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (56, 'PHY2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (57, 'PHY2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (57, 'ACC2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (58, 'ZUL2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (58, 'ENGH1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (59, 'VIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (59, 'TOU');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (59, 'EGD1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (60, 'VIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (61, 'ITN2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (61, 'BUS2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (62, 'HIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (63, 'CAT1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (63, 'CAT2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (64, 'CAT2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (64, 'ECO1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (64, 'PHY2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (64, 'ITN2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (65, 'HIS2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (65, 'GEO1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (65, 'LIF1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (66, 'ENGH2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (66, 'CON');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (66, 'ECO1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (66, 'PHY2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (67, 'AFRA2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (67, 'VIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (68, 'ACC2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (68, 'MATL2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (68, 'MAT2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (69, 'AFRA1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (70, 'MATL1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (71, 'CON');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (71, 'EGD1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (71, 'HIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (72, 'LIF2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (72, 'AFRA1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (72, 'AFRA2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (73, 'MAT2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (73, 'MAT1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (73, 'ENGA2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (74, 'ENGH1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (74, 'EGD1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (75, 'ENGH2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (76, 'ZUL2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (77, 'VIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (77, 'MATL1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (78, 'AFRA1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (78, 'HIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (79, 'ENGH1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (80, 'MAT2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (80, 'ACC1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (81, 'PHY2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (81, 'ENGH2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (82, 'LIF1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (83, 'ENGH2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (83, 'AFRA2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (84, 'GEO1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (85, 'EGD1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (85, 'ACC2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (85, 'ENGH2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (86, 'MATL2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (87, 'EGD2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (88, 'ENGA2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (89, 'PHY1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (90, 'HIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (90, 'CON');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (90, 'ITN1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (91, 'CAT2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (91, 'ENGH2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (91, 'VIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (91, 'AFRH2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (92, 'ENGH2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (92, 'HIS2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (93, 'PHY1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (93, 'ACC2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (94, 'PHY2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (94, 'VIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (95, 'BUS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (95, 'MAT1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (96, 'ENGA2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (97, 'AFRA1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (98, 'LIF2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (98, 'ACC2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (98, 'ENGH1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (98, 'CON');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (99, 'LIF1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (99, 'AFRA2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (99, 'ITN2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (99, 'HIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (99, 'AFRH2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (100, 'MATL1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (100, 'LIF1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (101, 'GEO1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (101, 'ENGH1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (102, 'AFRH1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (103, 'MATL2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (103, 'PHY2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (103, 'AFRH1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (104, 'HIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (105, 'LIF1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (105, 'ZUL2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (106, 'AFRH1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (106, 'ZUL2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (107, 'PHY1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (107, 'TOU');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (108, 'ZUL1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (109, 'EGD1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (109, 'MAT1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (110, 'LIF2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (110, 'BUS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (111, 'BUS2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (111, 'CON');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (112, 'PHY2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (113, 'ACC2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (113, 'VIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (114, 'ITN2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (114, 'BUS2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (114, 'CON');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (115, 'EGD1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (115, 'HIS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (115, 'ENGH1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (116, 'EGD1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (116, 'ZUL2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (116, 'LIF1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (116, 'AFRH1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (117, 'CAT2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (117, 'MAT2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (117, 'MAT1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (117, 'BUS1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (117, 'MATL1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (118, 'MAT1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (118, 'ECO1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (119, 'DRA');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (119, 'CON');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (119, 'AFRA2');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (119, 'AFRA1');
INSERT INTO `tblCandidates` (`StudentID`, `PaperID`) VALUES (120, 'ECO1');
# 269 records

#
# Table structure for table 'tblStudents'
#

DROP TABLE IF EXISTS `tblStudents`;

CREATE TABLE `tblStudents` (
  `StudentID` INTEGER NOT NULL AUTO_INCREMENT, 
  `Firstname` VARCHAR(50), 
  `Surname` VARCHAR(50), 
  `DateOfBirth` DATE, 
  `Gender` VARCHAR(1), 
  `Centre` INTEGER, 
  PRIMARY KEY (`StudentID`), 
  INDEX (`StudentID`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'tblStudents'
#

INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (1, 'Keiko', 'Abbott', '1999-03-30', 'F', 1003);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (2, 'Eagan', 'Alvarado', '2000-04-06', 'M', 1006);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (3, 'Cynthia', 'Andrews', '1999-05-08', 'F', 1000);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (4, 'Kelsie', 'Atkinson', '2000-04-09', 'F', 1007);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (5, 'Nichole', 'Avila', '2000-03-29', 'F', 1014);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (6, 'Colette', 'Baldwin', '2000-05-24', 'F', 1012);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (7, 'Tate', 'Bates', '2000-01-21', 'M', 1007);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (8, 'Fulton', 'Bauer', '1999-02-25', 'M', 1016);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (9, 'Hector', 'Beasley', '1999-12-30', 'M', 1019);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (10, 'Lynn', 'Becker', '2000-05-29', 'F', 1011);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (11, 'Ira', 'Bell', '1999-03-07', 'M', 1004);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (12, 'Alden', 'Bell', '2000-04-01', 'M', 1008);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (13, 'Alfreda', 'Bell', '2000-04-27', 'F', 1019);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (14, 'Vincent', 'Berg', '1999-11-30', 'M', 1012);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (15, 'Rigel', 'Blackburn', '1999-03-20', 'M', 1004);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (16, 'Deborah', 'Blackburn', '2000-05-19', 'F', 1005);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (17, 'Wanda', 'Blair', '2000-06-05', 'F', 1005);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (18, 'Oren', 'Blanchard', '1999-09-13', 'M', 1009);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (19, 'Keelie', 'Boyd', '1999-10-10', 'F', 1016);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (20, 'Beatrice', 'Bradshaw', '1999-10-18', 'F', 1019);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (21, 'Ivan', 'Brady', '2000-06-02', 'M', 1008);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (22, 'Hamish', 'Brewer', '1999-01-25', 'M', 1018);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (23, 'Paki', 'Bridges', '2000-04-12', 'M', 1012);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (24, 'May', 'Brock', '1999-12-05', 'F', 1017);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (25, 'Castor', 'Brown', '2000-02-14', 'M', 1015);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (26, 'Forrest', 'Bryan', '1999-03-27', 'M', 1016);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (27, 'Chancellor', 'Buck', '1999-03-29', 'M', 1017);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (28, 'Forrest', 'Burch', '1999-05-26', 'M', 1020);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (29, 'Cedric', 'Burgess', '2000-05-14', 'M', 1017);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (30, 'Jemima', 'Burton', '1999-10-31', 'F', 1013);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (31, 'Deborah', 'Cain', '1999-04-17', 'F', 1006);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (32, 'Erich', 'Carey', '2000-03-16', 'M', 1005);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (33, 'Jameson', 'Carrillo', '1999-05-13', 'M', 1009);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (34, 'Christopher', 'Carter', '2000-01-20', 'M', 1020);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (35, 'Nina', 'Chan', '2000-06-12', 'F', 1008);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (36, 'Barbara', 'Chan', '1999-01-10', 'F', 1018);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (37, 'Bethany', 'Chase', '1999-11-29', 'F', 1010);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (38, 'Uriel', 'Chavez', '1999-04-21', 'M', 1009);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (39, 'Carter', 'Christian', '1999-04-16', 'M', 1014);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (40, 'Eagan', 'Clark', '1999-02-10', 'M', 1011);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (41, 'Jael', 'Clay', '2000-05-22', 'F', 1003);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (42, 'Thor', 'Cleveland', '1999-04-30', 'M', 1018);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (43, 'Solomon', 'Cline', '2000-06-03', 'M', 1014);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (44, 'Kessie', 'Cline', '1999-04-15', 'F', 1014);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (45, 'Ezekiel', 'Collier', '1999-11-22', 'M', 1002);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (46, 'Harding', 'Colon', '2000-01-24', 'M', 1020);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (47, 'Demetria', 'Combs', '1999-01-27', 'F', 1006);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (48, 'Sarah', 'Cooke', '1999-10-30', 'F', 1014);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (49, 'Hayden', 'Daniel', '1999-09-13', 'M', 1003);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (50, 'Callum', 'Daugherty', '1999-01-14', 'M', 1007);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (51, 'Odette', 'Day', '1999-07-16', 'F', 1005);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (52, 'Hanna', 'Delacruz', '1999-01-18', 'F', 1009);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (53, 'Karyn', 'Delacruz', '2000-05-07', 'F', 1009);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (54, 'Whoopi', 'Diaz', '1999-11-07', 'F', 1017);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (55, 'Olympia', 'Dillon', '1999-11-28', 'F', 1007);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (56, 'Kathleen', 'Donovan', '1999-11-30', 'F', 1016);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (57, 'Walter', 'Duncan', '2000-04-14', 'M', 1014);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (58, 'Rahim', 'Edwards', '1999-12-24', 'M', 1020);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (59, 'Ahmed', 'Elliott', '1999-07-12', 'M', 1015);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (60, 'Quail', 'Erickson', '1999-10-24', 'F', 1017);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (61, 'Julie', 'Espinoza', '1999-12-31', 'F', 1006);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (62, 'Andrew', 'Faulkner', '2000-06-08', 'M', 1004);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (63, 'Sybill', 'Ferrell', '1999-10-24', 'F', 1008);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (64, 'Britanni', 'Fields', '1999-10-07', 'F', 1013);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (65, 'Fuller', 'Fisher', '1999-05-18', 'M', 1001);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (66, 'Astra', 'Fitzgerald', '1999-12-29', 'F', 1006);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (67, 'Chadwick', 'Fletcher', '1999-01-05', 'M', 1000);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (68, 'Laurel', 'Flynn', '1999-07-10', 'F', 1007);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (69, 'Clio', 'Forbes', '1999-12-31', 'F', 1003);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (70, 'Justine', 'Fox', '1999-05-20', 'F', 1017);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (71, 'Ian', 'Gaines', '1999-10-02', 'M', 1009);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (72, 'Garrison', 'Gallegos', '1999-12-27', 'M', 1009);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (73, 'Hasad', 'Garcia', '2000-01-25', 'M', 1005);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (74, 'Cameron', 'Garcia', '2000-06-04', 'M', 1006);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (75, 'Desirae', 'Gentry', '2000-02-11', 'F', 1014);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (76, 'Rae', 'Giles', '1999-03-13', 'F', 1017);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (77, 'Jackson', 'Gillespie', '1999-07-01', 'M', 1020);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (78, 'Melyssa', 'Gillespie', '2000-03-07', 'F', 1007);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (79, 'Emerald', 'Gilmore', '1999-03-30', 'F', 1000);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (80, 'Priscilla', 'Glover', '2000-03-19', 'F', 1015);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (81, 'Lila', 'Grant', '1999-09-13', 'F', 1001);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (82, 'Pandora', 'Green', '1999-02-16', 'F', 1001);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (83, 'Grace', 'Guthrie', '2000-01-26', 'F', 1012);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (84, 'Aladdin', 'Haley', '1999-01-02', 'M', 1020);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (85, 'Maggy', 'Harding', '1999-09-05', 'F', 1008);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (86, 'Adria', 'Hartman', '1999-06-06', 'F', 1006);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (87, 'Brenda', 'Haynes', '1999-03-12', 'F', 1009);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (88, 'Gannon', 'Hays', '1999-03-13', 'M', 1011);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (89, 'Deacon', 'Hays', '1999-10-31', 'M', 1000);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (90, 'Eugenia', 'Henderson', '1999-06-14', 'F', 1000);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (91, 'Kelly', 'Henson', '1999-12-11', 'M', 1015);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (92, 'Oleg', 'Herman', '1999-05-29', 'M', 1007);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (93, 'Kennedy', 'Hernandez', '2000-06-11', 'M', 1008);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (94, 'Alice', 'Herring', '2000-03-30', 'F', 1020);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (95, 'Maxwell', 'Hester', '1999-09-23', 'M', 1015);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (96, 'Alisa', 'Higgins', '1999-07-23', 'F', 1011);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (97, 'Berk', 'Hines', '1999-05-12', 'M', 1010);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (98, 'Jasper', 'Hinton', '1999-08-26', 'M', 1007);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (99, 'Imogene', 'Holden', '1999-04-13', 'F', 1008);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (100, 'Cora', 'Holmes', '1999-03-17', 'F', 1006);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (101, 'Shea', 'Hunt', '1999-11-09', 'F', 1005);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (102, 'Brady', 'Hurst', '1999-12-07', 'M', 1005);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (103, 'Fay', 'Hurst', '1999-07-30', 'F', 1012);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (104, 'Chase', 'Hutchinson', '1999-03-07', 'M', 1016);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (105, 'Lee', 'Jefferson', '2000-04-22', 'F', 1020);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (106, 'Alyssa', 'Joyner', '2000-05-10', 'F', 1005);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (107, 'Hakeem', 'Juarez', '1999-08-22', 'M', 1004);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (108, 'Abbot', 'Kemp', '2000-05-18', 'M', 1017);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (109, 'Eaton', 'King', '2000-06-15', 'M', 1011);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (110, 'Denise', 'Kinney', '2000-05-11', 'F', 1006);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (111, 'Cullen', 'Knapp', '2000-05-20', 'M', 1008);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (112, 'Gisela', 'Langley', '1999-08-11', 'F', 1015);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (113, 'Lois', 'Leon', '1999-08-26', 'F', 1006);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (114, 'Ivor', 'Levy', '2000-03-16', 'M', 1020);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (115, 'Jesse', 'Lloyd', '1999-09-14', 'M', 1016);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (116, 'Slade', 'Logan', '2000-05-18', 'M', 1020);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (117, 'Dylan', 'Lucas', '2000-05-29', 'M', 1020);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (118, 'Roanna', 'Madden', '2000-02-08', 'F', 1012);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (119, 'Alyssa', 'Mann', '1999-06-01', 'F', 1000);
INSERT INTO `tblStudents` (`StudentID`, `Firstname`, `Surname`, `DateOfBirth`, `Gender`, `Centre`) VALUES (120, 'Lila', 'Manning', '1999-12-15', 'F', 1019);
# 120 records

#
# Table structure for table 'tblTimeTable'
#

DROP TABLE IF EXISTS `tblTimeTable`;

CREATE TABLE `tblTimeTable` (
  `PaperID` VARCHAR(10) NOT NULL, 
  `ExamDate` DATE, 
  `Paper` VARCHAR(60), 
  `StartTime` TIME, 
  `EndTime` TIME, 
  PRIMARY KEY (`PaperID`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'tblTimeTable'
#

INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('ACC1', '2017-03-27', 'Accounting PI', '09:00:00', '11:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('ACC2', '2017-03-17', 'Accounting PII', '14:00:00', '16:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('AFRA1', '2017-03-02', 'Afrikaans First Add Language PI (Reading)', '14:00:00', '16:30:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('AFRA2', '2017-03-09', 'Afrikaans First Add Language PII (Writing)', '14:00:00', '16:30:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('AFRH1', '2017-03-01', 'Afrikaans Home Language PI (Reading)', '14:00:00', '17:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('AFRH2', '2017-03-08', 'Afrikaans Home Language PII (Writing)', '14:00:00', '17:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('BUS1', '2017-03-17', 'Business Studies PI', '09:00:00', '11:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('BUS2', '2017-03-15', 'Business Studies PII', '14:00:00', '16:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('CAT1', '2017-03-21', 'Computer Applications Technology PI (Theory)', '09:00:00', '12:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('CAT2', '2017-03-28', 'Computer Applications Technology PII (Practical)', '09:00:00', '12:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('CON', '2017-03-10', 'Consumer Studies', '09:00:00', '12:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('DRA', '2017-03-22', 'Dramatic Arts', '09:00:00', '12:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('ECO1', '2017-03-01', 'Economics', '09:00:00', '12:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('EGD1', '2017-03-23', 'Engineering Graphics & Design PI', '09:00:00', '12:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('EGD2', '2017-03-29', 'Engineering Graphics & Design PII', '09:00:00', '12:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('ENGA1', '2017-03-07', 'English First Add Language PI (Reading)', '14:00:00', '16:30:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('ENGA2', '2017-03-14', 'English First Add Language PII (Writing)', '14:00:00', '16:30:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('ENGH1', '2017-03-06', 'English Home Language PI (Reading)', '14:00:00', '17:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('ENGH2', '2017-03-13', 'English Home Language PII (Writing)', '14:00:00', '17:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('GEO1', '2017-03-24', 'Geography PI', '09:00:00', '12:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('GEO2', '2017-03-16', 'Geography PII', '14:00:00', '15:30:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('HIS1', '2017-03-20', 'History PI', '14:00:00', '17:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('HIS2', '2017-03-06', 'History PII', '09:00:00', '11:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('ITN1', '2017-03-20', 'Information Technology PI (Theory)', '09:00:00', '12:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('ITN2', '2017-03-30', 'Information Technology PII (Practical)', '09:00:00', '12:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('LIF1', '2017-03-15', 'Life Sciences PI', '09:00:00', '12:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('LIF2', '2017-03-31', 'Life Sciences PII', '09:00:00', '11:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('MAT1', '2017-03-07', 'Mathematics PI', '09:00:00', '12:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('MAT2', '2017-03-13', 'Mathematics PII', '09:00:00', '12:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('MATL1', '2017-03-08', 'Mathematical Literacy PI', '09:00:00', '12:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('MATL2', '2017-03-14', 'Mathematical Literacy PII', '09:00:00', '12:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('PHY1', '2017-03-02', 'Physical Sciences PI (Physics)', '09:00:00', '12:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('PHY2', '2017-03-03', 'Physical Sciences PII (Chemistry)', '09:00:00', '12:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('TOU', '2017-03-16', 'Tourism', '09:00:00', '12:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('VIS1', '2017-03-09', 'Visual Arts PI', '09:00:00', '12:00:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('ZUL1', '2017-03-03', 'IsiZulu First Add Language PI (Reading)', '14:00:00', '16:30:00');
INSERT INTO `tblTimeTable` (`PaperID`, `ExamDate`, `Paper`, `StartTime`, `EndTime`) VALUES ('ZUL2', '2017-03-10', 'IsiZulu First Add Language PII (Writing)', '14:00:00', '16:30:00');
# 37 records
