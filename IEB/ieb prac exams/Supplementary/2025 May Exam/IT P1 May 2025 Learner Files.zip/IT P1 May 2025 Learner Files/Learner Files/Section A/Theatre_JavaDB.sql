CREATE TABLE tblTheatres (
TheatreID INTEGER NOT NULL PRIMARY KEY 
GENERATED ALWAYS AS IDENTITY 
(START WITH 1, INCREMENT BY 1),
TName VARCHAR(60),
City VARCHAR(60),
TicketPrice INTEGER,
NumStaff INTEGER
);

CREATE TABLE tblPlays (
PlayID INTEGER NOT NULL PRIMARY KEY 
GENERATED ALWAYS AS IDENTITY 
(START WITH 1, INCREMENT BY 1),
PName VARCHAR(60),
PubDom BOOLEAN,
Fee INTEGER,
NumActors INTEGER
);

CREATE TABLE tblSales (
TheatreID INTEGER NOT NULL,
PlayID INTEGER NOT NULL,
ShowDate DATE,
Tickets INTEGER,
PRIMARY KEY (TheatreID, PlayID, ShowDate)
);

INSERT INTO tblTheatres (TName, City, TicketPrice, StageSize, NumStaff) VALUES 
('The Grand Globe','Johannesburg',410,17),
('Dramatic Acts','Cape Town',230,13),
('Community Playhouse','Durban',370,18),
('Theatre House','Johannesburg',190,12),
('Stage and Song','Cape Town',410,19),
('Dinner and Drama','Johannesburg',140,5),
('Grand Backstage','Gqeberha',360,16);

INSERT INTO tblPlays(PName, PubDom, Fee, NumActors) VALUES 
('Frankenstein',TRUE,0,11),
('Hello and Goodbye',FALSE,2075,2),
('Peter Pan',TRUE,0,32),
('Umabatha',FALSE,1825,46),
('Have You Seen Zandile',FALSE,2100,2),
('A Doll House',TRUE,0,10),
('When Life Gives Lemons',FALSE,1500,20);

INSERT INTO tblSales (TheatreID, PlayID, ShowDate, Tickets) VALUES 
(1,1,'2024-02-04',249),
(1,1,'2024-02-05',165),
(1,1,'2024-02-06',255),
(1,2,'2024-02-07',241),
(1,2,'2024-02-08',306),
(2,2,'2024-02-09',175),
(2,4,'2024-02-07',232),
(2,4,'2024-02-08',202),
(3,4,'2024-02-06',252),
(5,3,'2024-02-04',343),
(5,3,'2024-02-06',294),
(5,3,'2024-02-07',215),
(5,3,'2024-02-09',338),
(6,2,'2024-02-06',76),
(6,2,'2024-02-09',58),
(7,5,'2024-02-04',321),
(7,6,'2024-02-09',216);
