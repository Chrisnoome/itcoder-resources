CREATE TABLE tblChildren (
ChildID INTEGER NOT NULL PRIMARY KEY
GENERATED ALWAYS AS IDENTITY 
(START WITH 1, INCREMENT BY 1) ,
Firstname VARCHAR(60),
Lastname VARCHAR(60),
DOB Date,
ParentCellphone VARCHAR(60)
);

CREATE TABLE tblActivities (
ActivityID INTEGER NOT NULL PRIMARY KEY 
GENERATED ALWAYS AS IDENTITY 
(START WITH 1, INCREMENT BY 1),
Description VARCHAR(60),
CostPerPerson DOUBLE,
ActivityDays VARCHAR(60),
AllYear BOOLEAN
); 

CREATE TABLE tblSignUps (
SignUpID  INTEGER NOT NULL PRIMARY KEY 
GENERATED ALWAYS AS IDENTITY 
(START WITH 1, INCREMENT BY 1),
ActivityID INTEGER,
ChildID INTEGER,
SignUpDate Date
); 


INSERT INTO tblChildren (Firstname,Lastname,DOB,ParentCellphone)
VALUES
('Kaylyn','Furman','2014-06-18','0828842261'),
('Pride','Williams','2012-02-25','0627242377'),
('Xiluva','Zwane','2012-04-27','0725884662'),
('Sibulele','Sibaca','2013-04-01','0625435781'),
('Bradley','Ndlangisa','2008-11-01','0739347124'),
('Oratile','Hlanti','2007-12-13','0624359939'),
('Lyle','Mothwa','2010-05-15','0729324785'),
('Ongeziwe','Xulu','2011-01-26','0822068315'),
('Neliswa','Mhlongo','2010-01-15','0725193124'),
('Koketso','Zungu','2011-09-14','0625174635'),
('Lonathemba','Tlailane','2008-10-22','0821455896'),
('Ben','Makhabane','2008-09-03','0823135973'),
('Karabo','Khune','2006-11-16','0621456325'),
('Mosa','Martin','2008-07-25','0725063507'),
('Chris','Grobler','2013-06-19','0824789512'),
('Gabriela','Gamildien','2009-02-17','0627275532'),
('Ranveer','Singh','2011-10-22','0727053281'),
('Nonhlanhla','Tau','2011-09-07','0624443974'),
('Keagan','Coetzee','2013-07-31','0629750551'),
('Thapelo','Lebusa','2006-10-07','0725764630'),
('Thulani','Maela','2010-12-21','0624563214'),
('Luther','Morena','2007-03-10','0727896214'),
('Sipho','Tshabalala','2012-09-22','0822553053'),
('Siyanda','Motshwari','2011-04-18','0824567786'),
('Ronwen','Mokwena','2009-09-20','0621456287');

INSERT INTO tblActivities(Description,CostPerPerson,ActivityDays,AllYear)
VALUES
('Bike rides',55,'We,Fr',TRUE),
('Picnic in the park',75,'We,Th,Fr',TRUE),
('Stargazing',105,'We,Th,Fr',FALSE),
('Kids  science experiments',60,'Mo,Tu,We,Th,Fr,Sa',FALSE),
('Tennis tournament',50,'Mo,Tu,We,Th,Fr,Sa',TRUE),
('Make a kaleidoscope',110,'Fr,Sa',FALSE),
('Water balloon baseball',75,'Mo,We,Fr',TRUE),
('Paint rocks',100,'We,Fr',FALSE),
('Dig for fossils',65,'Mo,We,Fr',FALSE),
('Mountain hiking',80,'We,Fr',TRUE),
('Beach kite flying',65,'Mo,Tu,We',FALSE),
('Crafting with paper',95,'Mo,We,Fr',FALSE),
('Adventure book reading',100,'Fr,Sa',FALSE),
('Cardboard boat racing',120,'Mo,Tu,We,Th,Fr,Sa',FALSE);

INSERT INTO tblSignUps(ActivityID,ChildID,SignUpDate)
VALUES
(11,20,'2023-03-31'),
(14,14,'2023-04-08'),
(4,25,'2023-12-27'),
(2,16,'2023-10-04'),
(7,2,'2024-01-06'),
(11,6,'2023-04-07'),
(10,2,'2023-09-30'),
(7,10,'2023-12-31'),
(5,6,'2023-10-02'),
(11,8,'2023-03-25'),
(9,13,'2023-09-29'),
(10,21,'2023-03-24'),
(8,8,'2023-04-05'),
(10,20,'2023-03-26'),
(11,2,'2023-09-30'),
(8,7,'2023-10-07'),
(5,22,'2023-04-03'),
(8,21,'2023-10-05'),
(13,12,'2023-10-08'),
(7,11,'2023-04-02'),
(14,18,'2024-01-09'),
(8,23,'2023-03-30'),
(9,22,'2023-04-01'),
(9,1,'2024-01-05'),
(7,21,'2023-04-04'),
(10,9,'2023-12-27'),
(1,2,'2023-10-04'),
(11,23,'2023-03-25'),
(14,7,'2023-03-30'),
(8,13,'2023-12-29'),
(4,25,'2023-10-04'),
(14,7,'2023-03-31'),
(6,5,'2023-10-04'),
(6,18,'2024-01-14'),
(10,11,'2023-12-31'),
(13,8,'2023-10-06'),
(13,6,'2023-10-05'),
(14,20,'2023-03-25'),
(8,7,'2023-12-10'),
(9,1,'2023-12-10'),
(10,9,'2023-12-10'),
(14,7,'2023-12-10'),
(14,7,'2023-12-10'),
(6,5,'2023-12-10');



