unit DSertifikaat_U;
  //Sleutel jou eksamennommer hier in
interface

uses Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, ComCtrls, Spin, Math, DateUtils;

type
  TDigSertifikaat = class(TObject)
  private
    fSertHouer: String;
    fVervalDatum: String;
    fSekuriteitsKode: String;
    fUitreikNom: Integer;

  public
    procedure herstelVervalDatum;
    function hetVerval: boolean;
    function toString: String;
  end;

implementation

var
  sSysDatum: String;

// =============================================================================
// Vraag 2.1.1
// =============================================================================

// =============================================================================
// Vraag 2.1.2
// =============================================================================

// =============================================================================
// Vraag 2.1.3
// =============================================================================
procedure TDigSertifikaat.herstelVervalDatum;
begin
  //Kode wat voorsien is
  ShortDateFormat := ('dd/mm/yyyy');
  sSysDatum := FormatDateTime('dd/mm/yyyy', Date);

end;

// =============================================================================
// Vraag 2.1.4
// =============================================================================
function TDigSertifikaat.hetVerval: boolean;
begin
  //Kode wat voorsien is
  sSysDatum := FormatDateTime('dd/mm/yyyy', Date);
  ShowMessage(sSysDatum);

end;

// =============================================================================
// Vraag 2.1.5
// =============================================================================

// =============================================================================
// Vraag 2.1.6
// =============================================================================
function TDigSertifikaat.toString;
var
  sAfvoer: String;
begin
  sAfvoer := 'Inligting oor digitale sertifikaat:' + #13#13;
  sAfvoer := sAfvoer + 'Houer van sertifikaat: ' +  #13#13;
  sAfvoer := sAfvoer + 'Vervaldatum: ' + #13#13;
  sAfvoer := sAfvoer + 'Sekuriteitskode: ' + #13#13;
  sAfvoer := sAfvoer + 'Uitreiknommer: ' ;
  result := sAfvoer;
end;

end.
