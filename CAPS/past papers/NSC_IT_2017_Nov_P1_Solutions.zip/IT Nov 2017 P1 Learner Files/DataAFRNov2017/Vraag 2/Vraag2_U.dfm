object frmVraag2: TfrmVraag2
  Left = 0
  Top = 0
  Caption = 'Vraag 2'
  ClientHeight = 531
  ClientWidth = 533
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object Panel1: TPanel
    Left = 8
    Top = 8
    Width = 517
    Height = 41
    Caption = 'Digitale sertifikaat wat deur Easy-Secure uitgereik is'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 0
  end
  object Panel2: TPanel
    Left = 8
    Top = 55
    Width = 385
    Height = 58
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 1
    object Label1: TLabel
      Left = 10
      Top = 24
      Width = 100
      Height = 18
      Caption = 'Sertifikaathouer'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -15
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object edtSertHouer: TEdit
      Left = 151
      Top = 16
      Width = 218
      Height = 26
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -15
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
      TabOrder = 0
    end
  end
  object Panel3: TPanel
    Left = 8
    Top = 263
    Width = 517
    Height = 218
    TabOrder = 2
    object redAfvoer: TRichEdit
      Left = 10
      Top = 16
      Width = 495
      Height = 193
      Font.Charset = ANSI_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
      TabOrder = 0
    end
  end
  object Panel4: TPanel
    Left = 8
    Top = 119
    Width = 517
    Height = 138
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 3
    object btnV2_2_1: TButton
      Left = 9
      Top = 48
      Width = 232
      Height = 33
      Caption = '2.2.1 - Soek sertifikaathouer'
      TabOrder = 0
      OnClick = btnV2_2_1Click
    end
    object pnlV2_Buttons: TPanel
      Left = 255
      Top = 16
      Width = 250
      Height = 113
      TabOrder = 1
      Visible = False
      object btnV2_2_2: TButton
        Left = 24
        Top = 16
        Width = 200
        Height = 33
        Caption = '2.2.2 - Vertoon'
        TabOrder = 0
        OnClick = btnV2_2_2Click
      end
      object btnV2_2_3: TButton
        Left = 24
        Top = 65
        Width = 200
        Height = 33
        Caption = '2.2.3- Toets geldigheid'
        TabOrder = 1
        OnClick = btnV2_2_3Click
      end
    end
  end
  object btnClose: TBitBtn
    Left = 390
    Top = 487
    Width = 135
    Height = 36
    Caption = '&Sluit af'
    DoubleBuffered = True
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = []
    Kind = bkClose
    ParentDoubleBuffered = False
    ParentFont = False
    TabOrder = 4
  end
  object btnReset: TBitBtn
    Left = 8
    Top = 487
    Width = 129
    Height = 36
    Caption = '&Herstel'
    DoubleBuffered = True
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = []
    Kind = bkRetry
    ParentDoubleBuffered = False
    ParentFont = False
    TabOrder = 5
    OnClick = btnResetClick
  end
  object pnlDatum: TPanel
    Left = 399
    Top = 55
    Width = 126
    Height = 58
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = [fsItalic]
    ParentFont = False
    TabOrder = 6
  end
end
