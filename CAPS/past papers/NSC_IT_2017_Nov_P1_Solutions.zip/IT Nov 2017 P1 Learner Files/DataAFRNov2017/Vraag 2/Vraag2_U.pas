unit Vraag2_U;
  //Sleutel jou eksamennommer hier in
interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, DSertifikaat_U, StdCtrls, ExtCtrls, ComCtrls, DateUtils, Buttons;

type
  TfrmVraag2 = class(TForm)
    Panel1: TPanel;
    Panel2: TPanel;
    Label1: TLabel;
    Panel3: TPanel;
    Panel4: TPanel;
    btnV2_2_1: TButton;
    btnV2_2_2: TButton;
    redAfvoer: TRichEdit;
    btnClose: TBitBtn;
    btnReset: TBitBtn;
    pnlDatum: TPanel;
    edtSertHouer: TEdit;
    pnlV2_Buttons: TPanel;
    btnV2_2_3: TButton;
    procedure btnV2_2_1Click(Sender: TObject);
    procedure btnV2_2_2Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure btnResetClick(Sender: TObject);
    procedure btnV2_2_3Click(Sender: TObject);
  private
    { Private declarations }
    objDigSert: TDigSertifikaat;
  public
    { Public declarations }
  end;

var
  frmVraag2: TfrmVraag2;
  sSysDatum: String;   //Kode wat voorsien is

implementation

{$R *.dfm}

// ============================================================================
// Vraag 2.2.1
// ============================================================================
procedure TfrmVraag2.btnV2_2_1Click(Sender: TObject);
begin
  //Vraag 2.2.1
end;

// ============================================================================
// Vraag 2.2.2
// ============================================================================
procedure TfrmVraag2.btnV2_2_2Click(Sender: TObject);
begin
  //Vraag 2.2.2
end;

// ============================================================================
// Vraag 2.2.3
// ============================================================================
procedure TfrmVraag2.btnV2_2_3Click(Sender: TObject);
begin
  //Vraag 2.2.3
end;

{$Region 'Kode wat voorsien is'}
// ============================================================================
// Kode wat voorsien is
// ============================================================================
procedure TfrmVraag2.FormCreate(Sender: TObject);
begin
  ShortDateFormat := ('dd/mm/yyyy');
  DateSeparator := '/';
  sSysDatum := FormatDateTime('dd/mm/yyyy', Date);
  pnlDatum.Caption := sSysDatum;
  redAfvoer.Paragraph.TabCount := 1;
  redAfvoer.Paragraph.Tab[0] := 120;
  pnlV2_Buttons.Visible := false;
end;

procedure TfrmVraag2.btnResetClick(Sender: TObject);
begin
  pnlV2_Buttons.Visible := false;
  edtSertHouer.Clear;
  edtSertHouer.SetFocus;
  redAfvoer.Clear;
end;
//=============================================================================
{$EndRegion}
end.
