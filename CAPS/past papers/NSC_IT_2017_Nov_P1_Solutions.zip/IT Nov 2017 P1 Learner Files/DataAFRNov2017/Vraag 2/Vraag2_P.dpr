program Vraag2_P;

uses
  Forms,
  Vraag2_U in 'Vraag2_U.pas' {frmVraag2},
  DSertifikaat_U in 'DSertifikaat_U.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TfrmVraag2, frmVraag2);
  Application.Run;
end.
