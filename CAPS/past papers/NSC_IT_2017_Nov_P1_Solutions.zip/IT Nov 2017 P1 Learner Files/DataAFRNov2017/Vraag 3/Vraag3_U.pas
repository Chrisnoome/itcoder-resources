unit Vraag3_U;
// Sleutel jou eksamennommer hier in
interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Buttons, ExtCtrls, Grids, ComCtrls, Math;

type
  TfrmVraag3 = class(TForm)
    btnV3_1: TButton;
    btnV3_3: TButton;
    btnV3_2: TButton;
    pnlOpskrif: TPanel;
    redV3: TRichEdit;
    pnlButtons: TPanel;
    BitBtn1: TBitBtn;
    procedure FormCreate(Sender: TObject);
    procedure btnV3_1Click(Sender: TObject);
    procedure btnV3_2Click(Sender: TObject);
    procedure btnV3_3Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmVraag3: TfrmVraag3;

implementation

{$R *.dfm}
{$R+}

var
  arrAfdelings: array [1..8] of String = (
    'PC''s & Skootrekenaars',
    'Tablette & eLesers',
    'Sagteware',
    'Drukkers, Drukstof en Ink',
    'Selfone',
    'Speletjies & Hommeltuie',
    'Netwerktoerusting',
    'Bykomstighede');

  arrVerkope: array [1..8, 1..6] of Real = (
  (935.89, 965.99, 4056.77,5023.89, 3802.66, 1146.98),
  (2667.78, 2491.78, 1989.65, 2647.88,1601.56, 1921.99),
  (6702.45, 4271.56, 3424.45, 3924.55, 3085.45,3359.77),
  (6662.34, 6658.45, 8075.43, 2360.66, 2635.44, 7365.69),
  (16405.33, 9741.37, 13381.56, 18969.76, 8604.55, 20207.56),
  (10515.29, 7582.66, 9856.56, 7537.68, 9115.67, 8401.55),
  (7590.99, 9212.65, 9070.98, 6439.99, 7984.88, 8767.45),
  (9220.65, 8097.99, 10067.44, 9960.87, 10109.56, 6571.66));

  iBeginWeek: Integer = 1;

//====================================================================
// Vraag 3.1
//====================================================================
procedure TfrmVraag3.btnV3_1Click(Sender: TObject);
begin
  //Vraag 3.1
end;

//====================================================================
// Vraag 3.2
//====================================================================
procedure TfrmVraag3.btnV3_2Click(Sender: TObject);
begin
  //Vraag 3.2
end;

//====================================================================
// Vraag 3.3
//====================================================================
procedure TfrmVraag3.btnV3_3Click(Sender: TObject);
begin
  //Vraag 3.3
end;

{$REGION 'Kode wat voorsien is'}
//====================================================================
procedure TfrmVraag3.FormCreate(Sender: TObject);
var
  iKolom: Integer;
begin
  // ***  KODE WAT VOORSIEN IS  >> MOET DIT NIE VERANDER NIE !!!  ***
  CurrencyString := 'R ';
  ThousandSeparator := ' ';
  // Opstel van kolomme in die richEdit
  frmVraag3.Width := 780;
  redV3.Paragraph.TabCount := 6;
  redV3.Paragraph.Tab[0] := 175;
  for iKolom := 1 to 6 do
    redV3.Paragraph.Tab[iKolom] := 175 + (65 * iKolom);
end;
//====================================================================
{$ENDREGION}

end.
