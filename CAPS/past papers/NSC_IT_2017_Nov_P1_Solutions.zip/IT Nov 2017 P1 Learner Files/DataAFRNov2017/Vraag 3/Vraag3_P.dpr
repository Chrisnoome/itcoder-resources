program Vraag3_P;

uses
  Forms,
  Vraag3_U in 'Vraag3_U.pas' {frmVraag3};

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TfrmVraag3, frmVraag3);
  Application.Run;
end.
