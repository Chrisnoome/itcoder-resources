unit Vraag1_U;
//Sleutel jou eksamennommer hier in
interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ComCtrls, StdCtrls, pngimage, ExtCtrls, Buttons, Spin, Math;

type
  TfrmVraag1 = class(TForm)
    btnSluitAf: TBitBtn;
    PageControl1: TPageControl;
    tabVraag1_1: TTabSheet;
    pnlV1_1: TPanel;
    tabVraag1_2: TTabSheet;
    btnV1_2_2: TButton;
    tabVraag1_4: TTabSheet;
    tabVraag1_5: TTabSheet;
    pnlV1_5_1: TPanel;
    btnV1_5_1: TButton;
    redV1_5_1: TRichEdit;
    pnlV1_5_2: TPanel;
    btnV1_5_2: TButton;
    redV1_5_2: TRichEdit;
    tabVraag1_3: TTabSheet;
    imgKoekePic: TImage;
    lblGetalKoeke: TLabel;
    btnV1_3: TButton;
    cmbGetalKoeke: TComboBox;
    Panel4: TPanel;
    edtGetal1: TEdit;
    edtGetal2: TEdit;
    lblGetal1: TLabel;
    lblGetal2: TLabel;
    btnV1_2_1: TButton;
    edtV1_2_1: TEdit;
    Panel5: TPanel;
    edtWoord1: TEdit;
    edtWoord2: TEdit;
    lblWoord1: TLabel;
    lblWoord2: TLabel;
    Panel1: TPanel;
    rgpV1_4_1: TRadioGroup;
    pnlV1_4: TPanel;
    edtWagwoord: TEdit;
    lblWagwoord: TLabel;
    btnV1_4_2: TButton;
    pnlOpskrifV1_3: TPanel;
    lblKoste: TLabel;
    edtKoste: TEdit;
    edtPakkeSuiker: TEdit;
    lblPakkeSuiker: TLabel;
    lblSuikerInGram: TLabel;
    edtSuikerInGram: TEdit;
    btnV1_4_3: TButton;
    procedure btnV1_2_2Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure btnV1_3Click(Sender: TObject);
    procedure btnV1_5_2Click(Sender: TObject);
    procedure btnV1_5_1Click(Sender: TObject);
    procedure cmbGetalKoekeChange(Sender: TObject);
    procedure btnV1_2_1Click(Sender: TObject);
    procedure rgpV1_4_1Click(Sender: TObject);
    procedure btnV1_4_2Click(Sender: TObject);
    procedure btnV1_4_3Click(Sender: TObject);

  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmVraag1: TfrmVraag1;
  // Kode wat voorsien is
  iGetalKoeke: integer;
  sWagwoord: String;

implementation

{$R *.dfm}

//=============================================================================
// Vraag 1.1
//=============================================================================
procedure TfrmVraag1.FormCreate(Sender: TObject);
begin
  //Vraag 1.1
end;

//=============================================================================
// Vraag 1.2.1
//=============================================================================
procedure TfrmVraag1.btnV1_2_1Click(Sender: TObject);
begin
  //Vraag 1.2.1
end;

//=============================================================================
// Vraag 1.2.2
//=============================================================================
procedure TfrmVraag1.btnV1_2_2Click(Sender: TObject);
// Kode wat voorsien is
var
  sWoord1, sWoord2: String;
  sTempWoord: String;
begin
   //Vraag 1.2.2
end;

//=============================================================================
// Vraag 1.3.1
//=============================================================================
procedure TfrmVraag1.cmbGetalKoekeChange(Sender: TObject);
// Kode wat voorsien is
const
  PRYS = 159.50;
begin
  //Vraag 1.3.1
end;

//=============================================================================
// Vraag 1.3.2
//=============================================================================
procedure TfrmVraag1.btnV1_3Click(Sender: TObject);
// Kode wat voorsien is
const
  SUIKER = 375;
begin
  //Vraag 1.3.2
end;

//=============================================================================
// Vraag 1.4.1
//=============================================================================
 procedure TfrmVraag1.rgpV1_4_1Click(Sender: TObject);
begin
  //Vraag 1.4.1
end;

//=============================================================================
// Vraag 1.4.2
//=============================================================================
procedure TfrmVraag1.btnV1_4_2Click(Sender: TObject);
begin
  //Vraag 1.4.2
end;

//=============================================================================
// Vraag 1.4.3
//=============================================================================
procedure TfrmVraag1.btnV1_4_3Click(Sender: TObject);
begin
  //Vraag 1.4.3
end;

//=============================================================================
// Vraag 1.5.1
//=============================================================================
procedure TfrmVraag1.btnV1_5_1Click(Sender: TObject);
begin
  //Vraag 1.5.1
end;

//=============================================================================
// Vraag 1.5.2
//=============================================================================
procedure TfrmVraag1.btnV1_5_2Click(Sender: TObject);
// Kode wat voorsien is
const
    VERMENIGVULDIGER = 3;
begin
  //Vraag 1.5.2
end;

end.
