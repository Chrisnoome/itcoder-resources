program Vraag1_P;

uses
  Forms,
  Vraag1_U in 'Vraag1_U.pas' {frmVraag1};

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TfrmVraag1, frmVraag1);
  Application.Run;
end.
